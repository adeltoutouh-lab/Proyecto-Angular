import { TestBed } from '@angular/core/testing';
import { Blog } from './blog';

describe('Blog', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Blog]
    }).compileComponents();
  });

  it('debería crear el componente', () => {
    const fixture = TestBed.createComponent(Blog);
    const component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });
});
