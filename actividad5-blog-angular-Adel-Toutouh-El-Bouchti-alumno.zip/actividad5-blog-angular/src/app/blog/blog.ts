import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Noticia } from './noticia.interface';

@Component({
  selector: 'app-blog',
  imports: [CommonModule, FormsModule],
  templateUrl: './blog.html',
  styleUrl: './blog.css'
})
export class Blog {
  noticias: Noticia[] = [
    {
      titulo: 'Angular facilita la creación de páginas web',
      imagen: '/imagenes/angular.svg',
      texto: 'Angular es un framework que permite crear aplicaciones web utilizando componentes y TypeScript.',
      fecha: '2026-07-08'
    },
    {
      titulo: 'La programación tiene cada vez más salidas laborales',
      imagen: '/imagenes/inteligencia-artificial.svg',
      texto: 'Muchas empresas buscan personas con conocimientos de programación, análisis de datos y desarrollo web.',
      fecha: '2026-07-10'
    }
  ];

  titulo: string = '';
  imagen: string = '';
  texto: string = '';
  fecha: string = '';

  guardarNoticia(): void {
    if (this.titulo === '' || this.imagen === '' || this.texto === '' || this.fecha === '') {
      alert('Todos los campos son obligatorios');
    } else {
      const nuevaNoticia: Noticia = {
        titulo: this.titulo,
        imagen: this.imagen,
        texto: this.texto,
        fecha: this.fecha
      };

      this.noticias.push(nuevaNoticia);

      this.titulo = '';
      this.imagen = '';
      this.texto = '';
      this.fecha = '';
    }
  }
}
