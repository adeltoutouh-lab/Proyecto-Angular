# Actividad 5 - Blog en Angular

Práctica de la asignatura Full Stack Developer.

Alumno: Adel Toutouh El Bouchti

La aplicación permite añadir noticias mediante un formulario y mostrarlas en un listado.

## Ejecutar el proyecto

```bash
npm install
ng serve
```

Después hay que abrir `http://localhost:4200/`.
